import { useMemo, useState } from 'react';
import { Camera, Globe, Instagram, Mail } from 'lucide-react';
import { MinimalistHero } from '@/src/components/MinimalistHero';
import { WorksWheel } from '@/src/components/WorksWheel';
import { SelectedWorks } from '@/src/components/SelectedWorks';
import { ApproachSection } from '@/src/components/ApproachSection';
import { ArchiveIndex } from '@/src/components/ArchiveIndex';
import { InquirySection } from '@/src/components/InquirySection';
import { LightboxModal } from '@/src/components/LightboxModal';
import {
  ARCHIVE_ENTRIES,
  HERO_PORTRAIT_SRC,
  PORTFOLIO_WORKS,
  PortfolioWork,
  STUDIO_DISCIPLINES,
  STUDIO_METRICS,
} from '@/src/data/portfolio';

export function App() {
  const [activeWork, setActiveWork] = useState<PortfolioWork | null>(null);

  const wheelItems = useMemo(
    () =>
      PORTFOLIO_WORKS.map((work) => ({
        title: work.title,
        image: work.imageSrc,
        href: `#${work.id}`,
      })),
    []
  );

  return (
    <div className="min-h-screen bg-background text-foreground">
      <MinimalistHero
        logoText="KOVA."
        navLinks={[
          { label: 'Work', href: '#work' },
          { label: 'Catalog', href: '#catalog' },
          { label: 'Approach', href: '#approach' },
          { label: 'Archive', href: '#archive' },
        ]}
        primaryAction={{ label: 'Inquire', href: '#contact' }}
        mainText="Maren Kova directs architectural monographs, tactile object studies, and quiet editorial photography from Copenhagen."
        readMoreLink="#work"
        readMoreLabel="Explore Selected Works"
        imageSrc={HERO_PORTRAIT_SRC}
        imageAlt="Studio portrait of creative director Maren Kova"
        overlayText={{
          part1: 'less is',
          part2: 'more.',
        }}
        socialLinks={[
          { icon: Instagram, label: 'Instagram', href: 'https://instagram.com' },
          { icon: Camera, label: 'Photography Archive', href: '#work' },
          { icon: Globe, label: 'Exhibitions', href: '#archive' },
          { icon: Mail, label: 'Email Studio', href: '#contact' },
        ]}
        locationText="Copenhagen, Denmark"
      />

      <main>
        {/* Immediate section after Hero: Interactive 3D WorksWheel */}
        <div id="work" className="relative h-screen min-h-[640px] w-full border-t border-border">
          <WorksWheel
            items={wheelItems}
            label="Works '26"
            action="View"
            onItemClick={(_, index) => {
              const work = PORTFOLIO_WORKS[index];
              if (work) setActiveWork(work);
            }}
          />
        </div>

        <div id="catalog" className="border-t border-border">
          <SelectedWorks works={PORTFOLIO_WORKS} onSelectWork={setActiveWork} />
        </div>

        <ApproachSection disciplines={STUDIO_DISCIPLINES} metrics={STUDIO_METRICS} />

        <ArchiveIndex
          entries={ARCHIVE_ENTRIES}
          works={PORTFOLIO_WORKS}
          onSelectWork={setActiveWork}
        />
      </main>

      <InquirySection />

      <LightboxModal
        work={activeWork}
        works={PORTFOLIO_WORKS}
        onClose={() => setActiveWork(null)}
        onNavigate={setActiveWork}
      />
    </div>
  );
}

export default App;
