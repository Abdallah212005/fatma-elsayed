import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { PortfolioWork, WorkCategory } from '@/src/data/portfolio';
import { ResilientImage } from '@/src/components/ResilientImage';
import { cn } from '@/src/lib/utils';

interface SelectedWorksProps {
  works: PortfolioWork[];
  onSelectWork: (work: PortfolioWork) => void;
}

const CATEGORIES: WorkCategory[] = ['All', 'Architecture', 'Editorial', 'Object', 'Campaign'];

export const SelectedWorks: React.FC<SelectedWorksProps> = ({ works, onSelectWork }) => {
  const [activeCategory, setActiveCategory] = useState<WorkCategory>('All');

  const filteredWorks = useMemo(() => {
    if (activeCategory === 'All') return works;
    return works.filter((w) => w.category === activeCategory);
  }, [works, activeCategory]);

  return (
    <section className="mx-auto w-full max-w-7xl px-6 py-20 sm:px-10 md:px-12 md:py-28">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
        className="flex flex-col justify-between gap-6 border-b border-border pb-8 md:flex-row md:items-end"
      >
        <div>
          <p className="text-xs font-medium tracking-wide text-foreground/60">
            Selected Works · 2025–2026
          </p>
          <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-foreground text-balance sm:text-4xl">
            Curated commissions across space, form, and print.
          </h2>
        </div>

        {/* Functional Category Filter Tabs */}
        <div
          role="tablist"
          aria-label="Filter projects by category"
          className="flex flex-wrap items-center gap-1 rounded-lg bg-surface p-1 self-start md:self-auto"
        >
          {CATEGORIES.map((category) => {
            const isActive = activeCategory === category;
            return (
              <button
                key={category}
                role="tab"
                type="button"
                aria-selected={isActive}
                onClick={() => setActiveCategory(category)}
                className={cn(
                  'whitespace-nowrap shrink-0 rounded-md px-3.5 py-2 text-xs font-medium transition-colors duration-150',
                  isActive
                    ? 'bg-background text-foreground shadow-sm'
                    : 'text-foreground/65 hover:text-foreground'
                )}
              >
                {category}
              </button>
            );
          })}
        </div>
      </motion.div>

      {/* Bento Photography Grid */}
      <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-3">
        {filteredWorks.map((work, index) => {
          const isSingleFiltered = filteredWorks.length === 1;
          const gridSpanClass = isSingleFiltered
            ? 'md:col-span-3 min-h-[380px] md:min-h-[500px]'
            : activeCategory === 'All'
            ? work.aspectClass
            : index === 0
            ? 'md:col-span-2 min-h-[340px]'
            : 'md:col-span-1 min-h-[340px]';

          return (
            <motion.article
              key={work.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{ duration: 0.55, delay: Math.min(index * 0.06, 0.24), ease: [0.22, 1, 0.36, 1] }}
              className={cn(
                'group relative overflow-hidden rounded-2xl border border-border bg-surface',
                gridSpanClass
              )}
            >
              <button
                type="button"
                onClick={() => onSelectWork(work)}
                className="relative block h-full w-full text-left focus-visible:outline-none"
                aria-label={`Open ${work.title} case study`}
              >
                <div className="h-full w-full overflow-hidden">
                  <ResilientImage
                    src={work.imageSrc}
                    alt={work.imageAlt}
                    fallbackTitle={work.title}
                    className={cn(
                      'h-full w-full object-cover transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.04]',
                      work.imageScaleClass
                    )}
                  />
                </div>

                {/* Measured Contrast Scrim */}
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent opacity-85 transition-opacity duration-200 group-hover:opacity-95"
                />

                {/* Card Content */}
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-6 text-white">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-white/75">
                      <span>{work.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{work.year}</span>
                      <span aria-hidden="true">·</span>
                      <span>{work.location}</span>
                    </div>
                    <h3 className="mt-1.5 font-display text-xl font-semibold tracking-tight text-white sm:text-2xl">
                      {work.title}
                    </h3>
                  </div>

                  <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/15 text-white backdrop-blur-sm transition-colors duration-150 group-hover:bg-[#F2B705] group-hover:text-[#0E0E10]">
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </span>
                </div>
              </button>
            </motion.article>
          );
        })}
      </div>
    </section>
  );
};
